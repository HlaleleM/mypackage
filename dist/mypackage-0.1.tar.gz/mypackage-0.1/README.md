#mypackage
This library is created as one of my first package and also part of learning on how to publish my find_packages

##building this package locally
`python setup.py sdist`

##installing this package from GitHub
`pip install git+https://github.com/HlaleleM/mypackage.git`

##updating this package from GitHub
`pip install --upgrade git+https://github.com/HlaleleM/mypackage.git`
